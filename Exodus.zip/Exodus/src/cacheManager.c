//
// Created by ezio on 28/08/19.
//

#include "headers/hashFunction.h"

struct image imageToInsert;


//this function is called by the ServerBranch to chech
//if an image is present into the cache
//if this function returns 0 it means that the bytes of the image
//that the branch is looking for, have not been copied
//if it returns 1 it means that imageToGet.imageBytes
//has been copied from the cache to imageToGet->imageBytes
int getImageInCache(struct image *imageToGet)
{
    //printf("getImageInCache from branch %d\n", getpid());
    
    int key = hashFunction(*imageToGet);

    //printf("heash_key generated in getImage: %d\n", key);

    struct hash_element *hashElement = (cache + key);

    struct image *tempImage;

    errno = 0;
    
    //printf("2 trywaiting semToHashBlock in cache, reader\n");
    int tryWaitResult = sem_trywait(&(hashElement->semToHashBlock));

    if(errno != EAGAIN && tryWaitResult == -1){
        perror("Error in semwait (getImage in cache)");
        return -1;
    }

    //printf("2/3 trywaiting dontRead in cache, councurrent read\n");
    if(sem_wait(&(hashElement->dontRead)) == -1 ){
            perror("Error in semwait (dontRead, getImage)");
            return -1;
    }

    //the cache readers will able to unlock 'dontRead' semaphores
    //in order to allow them to read in cache concurrently
    //printf("3 posting dontread in cache, reader\n");
    if(sem_post(&(hashElement->dontRead)) == -1 ){
        perror("Error in sempost (dontRead, getImage)");
        return -1;
    }

    for(int i = 0;i < MAX_IMAGE_NUM_PER_KEY; ++i) {

        tempImage = (hashElement->conflictingImages);
        
        //printf("Looking for image in cache, in %d hash_element and i: %d\n", key, i);

        //if the counters of a conflictingImages is 0
        //it means that the element is not in cache
        if (tempImage->counter == 0 && errno != EAGAIN) {

            //printf("4 posting in semToHashBlock in cache, reader, because of counter\n");
            if(sem_post(&(hashElement->semToHashBlock)) == -1 ){
                perror("Error in sempost (getImage in cache)");
                return -1;
            }

            errno = 0;

            return 0;

        }

        //printf("1\n");
        
        if(strcmp(tempImage->name, imageToGet->name) != 0)
            continue;

        //printf("2\n");

        if(tempImage->quality != imageToGet->quality)
            continue;

        //printf("3\n");

        if(tempImage->width != imageToGet->width)
            continue;

        //printf("4\n");

        if(tempImage->height != imageToGet->height)
            continue;

        //printf("5\n");

        if(imageToGet->isPng != 2 && tempImage->isPng != imageToGet->isPng)
            continue;

        //printf("6\n");

        //here the image has been found
        tempImage->counter++;

        memcpy(imageToGet->imageBytes, tempImage->imageBytes, tempImage->imageSize);
        imageToGet->isPng = tempImage->isPng;
        imageToGet->imageSize = tempImage->imageSize;

        //the semaphore has to be unlocked only by the reader that has posted it
        if(errno != EAGAIN) {
            //printf("4 posting in semToHashBlock in cache, by the reader in for\n");
            if (sem_post(&(hashElement->semToHashBlock)) == -1) {
                perror("Error in sempost (getImage in cache)");
                return -1;
            }
            
            //resetting errno
            errno = 0;
        }

        //printf("Found in position %d\n", i);
        //printf("Its counter is %d\n", tempImage->counter);
        
        return 1;

    }

    //the semaphore has to be unlocked only by the reader that has posted it
    if(errno != EAGAIN) {
            //printf("4 posting in semToHashBlock in cache, by the reader out for\n");
            if (sem_post(&(hashElement->semToHashBlock)) == -1) {
                perror("Error in sempost (getImage in cache)");
                return -1;
            }
            
            //resetting errno
            errno = 0;
    }

    errno = 0;

    //if the function reaches this point it means
    //that all the images saved into the hash_elementare not the requested one
    return 0;

}



//this function is called by the cacheManager to insert
//a new image into the cache
int insert()
{
    //printf("Branch %d inserting image in cache\n", getpid());

    int key = hashFunction(imageToInsert);
    //printf("heash_key generated in insert: %d\n", key);

    struct hash_element *hashElement = (cache + key);

    struct image *imageSet = hashElement->conflictingImages;

    //takeing the counter of the first image into the hash_element selected
    int selectedPosition = (imageSet + 0)->counter;

    //inserting ino the right position
    for(int j = 0; j < MAX_IMAGE_NUM_PER_KEY; ++j){

        if(selectedPosition < (imageSet + j)->counter )
            selectedPosition = (imageSet + j)->counter;
    }

    //printf("6 waiting semToHashBlock inserting\n");
    if(sem_wait(&(hashElement->semToHashBlock)) == -1 ){
        perror("Error in semwait (insert in cache)");
        return -1;
    }

    //locking the readers
    //printf("7 waiting dontRead inserting\n");
    if(sem_wait(&(hashElement->dontRead)) == -1 ){
        perror("Error in semwait (insert, getImage)");
        return -1;
    }

    //the image with the minimum counter has been selected, inserting
    (imageSet + selectedPosition)->counter = 1;

    (imageSet + selectedPosition)->imageSize = imageToInsert.imageSize;
    (imageSet + selectedPosition)->width = imageToInsert.width;
    (imageSet + selectedPosition)->height = imageToInsert.height;
    (imageSet + selectedPosition)->quality = imageToInsert.quality;
    (imageSet + selectedPosition)->isPng = imageToInsert.isPng;
    memcpy((imageSet + selectedPosition)->name, imageToInsert.name, strlen(imageToInsert.name));
    memcpy((imageSet + selectedPosition)->imageBytes, imageToInsert.imageBytes, imageToInsert.imageSize);
    (imageSet + selectedPosition)->imageSize = imageToInsert.imageSize;

    //printf("Inserted image in cache, in %d position and i (in image array): %d\n", key, selectedPosition);

    //unlocking readers
    //printf("8 posting dontRead inserting\n");
    if(sem_post(&(hashElement->dontRead)) == -1 ){
        perror("Error in sempost (dontRead, getImage)");
        return -1;
    }

    //unlocking writers og the cache
    //printf("9 posting semToHashBlock inserting\n");
    if(sem_post(&(hashElement->semToHashBlock)) == -1 ){
        perror("Error in semwait (insert in cache)");
        return -1;
    }

    return 0;
}


//when the cache manager is called he has to check
//1.   if a struct image is present into the cache
//1.1  return the image
// OR
//2.   write a struct image given by the ServerBranch into the cache
//     this has to be done by a thread parallel to the ServerBranch
void cacheManager()
{
    //attaching to the cache
    while(1){

        //printf("cacheManager %d waiting the branch\n", getpid());

        //printf("A) waiting in activateCacheManager, writer\n");
        //waiting to insert a new element into the cache
        if(sem_wait(&activateCacheManager) == -1){
            perror("Error in semwait (activateCacheManager)");
            return;
        }

        if(insert()){
            perror("Error insert");
            return;
        }

        //printf("B) posting in cacheManagerHasFinished, writer\n");
        //posting to insert a new element into the cache
        if(sem_post(&cacheManagerHasFinished) == -1){
            perror("Error in sempost (cacheManagerHasFinished)");
            return;
        }
    }

}