#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>


void main(int argc, char **argv)
{
	if(argc < 4){
		printf("Usage: ./clientGenerator.out <NUM_CLIENTS> <SERVER_PORT> <SERVER_ADDRESS>\n");
		exit(-1);
	}

	int num = atoi(argv[1]);
	int port = atoi(argv[2]);
	printf("Generating %d clients on localhost over port: %d, good luck\n", num, port);

	for(int i = 0; i < num; ++i){

		if(!fork()){
			//child
			execlp("x-terminal-emulator", "x-terminal-emulator", "-H", "-e", "telnet", argv[3], argv[2], NULL);
			perror("Error in execl: ");
			exit(-1);
		}
	}
}